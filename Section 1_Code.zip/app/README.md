# Video 1.1 Application

Resources for the Video course
A simple Node.js application to be built as a Docker container
