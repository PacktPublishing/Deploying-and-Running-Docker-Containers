# Video 2.2 Application

Resources for the Video course

A Dockerfile definition building a simple NodeJS application
