name 'docker'

default_source :supermarket

run_list 'docker::default'
named_run_list 'manager', 'docker::manager'

cookbook 'docker', path: './cookbooks/docker'
