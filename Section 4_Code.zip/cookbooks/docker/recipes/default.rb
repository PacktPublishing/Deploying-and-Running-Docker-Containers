# cookbooks/docker/recipes/default.rb

node.default['chef_client']['interval'] = 300
node.default['chef_client']['splay'] = 30

include_recipe 'chef-client::service'

yum_repository 'docker' do
  description 'Docker CE repository'
  baseurl 'https://download.docker.com/linux/centos/7/$basearch/stable'
  gpgkey 'https://download.docker.com/linux/centos/gpg'
  enabled true
  action :create
end

package 'docker-ce'

directory '/etc/docker'

config_file = file '/etc/docker/daemon.json' do
  content <<~eos
    { 
      "storage-driver": "devicemapper"
    }
  eos
end

ruby_block 'restart docker' do
  block do
    resources('service[docker]').action %w(enable start restart)
  end
  only_if { config_file.updated_by_last_action? }
end

service 'docker' do
  action %w(enable start)
end

# cookbooks/docker/recipes/default.rb
# Docker Swarm
require 'chef-vault'

swarm = ChefVault::Item.load 'docker', 'swarm'

execute 'join swarm' do
  command 'docker swarm join '\
          "--token #{swarm['token']} #{swarm['manager']}"
  not_if 'docker info -f "{{.Swarm.LocalNodeState}}" | egrep "^active"'
end
