creds = com.cloudbees.plugins.credentials.CredentialsProvider.lookupCredentials(
      com.cloudbees.plugins.credentials.Credentials.class
)

i = jenkins.model.Jenkins.instance
i.systemMessage = ""

if (creds.find { it.id == "dockerhub" } == null) {
  i.systemMessage += "Need to provide dockerhub credentials\n"
}

if (creds.find { it.id == "production" } == null) {
  i.systemMessage += "Need to provide credentials to production environment\n"
}

i.save()
